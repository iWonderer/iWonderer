<?php
    include 'assets/php/session-header.php';
	$base->unsetSession();
    header("Location: login.php");
